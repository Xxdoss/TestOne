const express = require('express');
const path = require('path');

const app = express();

const { rateLimit } = require('express-rate-limit');

const limiterDefault = rateLimit({
	windowMs: 3 * 60 * 1000, // 3 minutes
	max: 400, // Limit each IP to 400 requests per `window`
	standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
	legacyHeaders: false, // Disable the `X-RateLimit-*` headers
    message: `<div style='margin-left:auto;margin-right:auto;color:#ff3535;text-align:center;
    margin-top:20%;font-size:34px;font-weight:600;width:440px;height:auto;background:#ededed69;border-radius:4px;'> 
    Too many requests</div>`
})

app.use(limiterDefault);

app.use('',express.static(path.join(__dirname,'public')));
app.get('/', (request, response) => {
	return response.sendFile('public/html/index.html', { root: '.' });
});

const port = 5000;

app.listen(port, () => console.log(`App listening at http://localhost:${port}`));

app.post("/form", (async (request, response) => {

    const buffers = []; 
    for await (const chunk of request) { buffers.push(chunk) };
  
    const data = JSON.parse(Buffer.concat(buffers).toString());
    console.log(data);
    response.json(true);

}))

