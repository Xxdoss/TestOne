const send = document.querySelector(".send_form")
const fio = document.getElementById('fio')
const tel = document.getElementById('tel')
const email = document.getElementById('email')
const text = document.getElementById('text')
const res = document.querySelector('.response_status')

send.addEventListener('click', ()=>{
    const status = validateForm(fio.value,tel.value,email.value)
    if(status.fio==true&&status.tel==true&&status.email==true){
        fioerr.style.cssText = `color:var(--theme-color)`
        telerr.style.cssText = `color:var(--theme-color)`
        emailerr.style.cssText = `color:var(--theme-color)`

        sendForm(fio.value,phoneMask(tel.value),email.value,text.value)
    }
    else{displayError(status)}
})

function validateForm(fio,tel,email){

    const status = {fio:false,tel:false,email:false}

    if(fio.length!=0){status.fio = true}
    if(phoneMask(tel).length==18){status.tel = true}
    if(validEmail(email)==true){status.email = true}

    return status
}

function phoneMask(tele) {
    let num = tele.replace(/[^0-9]/g,"")
    const regex = /(\d?)(\d{3})(\d{3})(\d{2})(\d{2})/g
    const subst = "+$1 ($2) $3-$4-$5"
    return num.replace(regex, subst)
}

function validEmail(email) {
    let re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return re.test(String(email).toLowerCase())
}

function displayError(status){
    if(status.fio==false){fioerr.style.cssText = `color:red`} 
    if(status.tel==false){telerr.style.cssText = `color:red`} 
    if(status.email==false){emailerr.style.cssText = `color:red`} 
}

async function sendForm(fio,tel,email,text){

    const req = await fetch("/form", {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            fio : fio,
            tel : tel,
            email : email,
            text : text
        })
    });

    const res = await req.json()

    if(req.status == 200){
        displayResponse(res)
    }
    else{
        displayResponse(false)
    }
}

function displayResponse(param){

    if(param==true){
        res.style.cssText = `display:block`
    }
    else{
        res.style.cssText = `display:block; background-color: red;`
        res.textContent = "Ошибка"
    }
}